### FOOD SECURITY Project

This project was made by DataLab Fellows for our partner, the South Cumberland Summer Meal Program. This project is a solution proposed by DataLab to help our partner predict demand (the number of people) arriving at a meal site during the meal program. It is a dashboard with insights and a predictive model incorporated. It was built using Data Science and Applied Machine Learning in Python. 

This is an open source code to help and impact others :)

By Eden Alem, Bryce Comer, Orion Gant and Carson Coody - DataScience Fellows at DataLab
